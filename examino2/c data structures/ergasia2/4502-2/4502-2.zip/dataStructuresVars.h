#ifndef DATA_STRUCTURES_VARS_H
#define DATA_STRUCTURES_VARS_H

/* STACK (STIVA) */

struct StackData{
    
};

typedef struct StackData StackData;

/* QUEUE (OURA) */

struct QueueData{
    
};

typedef struct QueueData QueueData;

/* PRIORITY QUEUE (OURA PROTERAIOTITAS) */

struct PQData{
    
};

typedef struct PQData PQData;

/* LINKED LIST (SINDEDEMENI LISTA) */

struct LLData{
    
};

typedef struct LLData LLData;

/* BINARY TREE (DIADIKO DENTRO) */

struct BTData{
    int hours;
    int location;
};

typedef struct BTData BTData;

#endif